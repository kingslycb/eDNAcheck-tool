##############################################################################
#
# PostgreSQL Installation and Configuration Helper for Windows
# Helps with PostgreSQL setup and troubleshooting
#
##############################################################################

import subprocess
import os
import sys
import psycopg2
import getpass

def check_postgresql_service():
    """Check if PostgreSQL service is running on Windows"""
    try:
        result = subprocess.run(
            ['sc', 'query', 'postgresql-x64-14'], 
            capture_output=True, text=True, shell=True
        )
        if "RUNNING" in result.stdout:
            print("✅ PostgreSQL service is running")
            return True
        else:
            print("❌ PostgreSQL service is not running")
            return False
    except Exception as e:
        print(f"Could not check PostgreSQL service status: {e}")
        return False

def start_postgresql_service():
    """Start PostgreSQL service on Windows"""
    try:
        print("Attempting to start PostgreSQL service...")
        result = subprocess.run(
            ['net', 'start', 'postgresql-x64-14'], 
            capture_output=True, text=True, shell=True
        )
        if result.returncode == 0:
            print("✅ PostgreSQL service started successfully")
            return True
        else:
            print(f"❌ Failed to start PostgreSQL service: {result.stderr}")
            return False
    except Exception as e:
        print(f"Error starting PostgreSQL service: {e}")
        return False

def test_connection(host='localhost', port=5432, user='postgres', password=None):
    """Test PostgreSQL connection"""
    try:
        if password is None:
            password = getpass.getpass("Enter PostgreSQL password: ")
        
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database='postgres'
        )
        conn.close()
        print("✅ PostgreSQL connection successful")
        return True, password
    except psycopg2.OperationalError as e:
        print(f"❌ PostgreSQL connection failed: {e}")
        return False, None
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False, None

def check_postgresql_installation():
    """Check if PostgreSQL is installed"""
    try:
        # Check if psql command is available
        result = subprocess.run(['psql', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ PostgreSQL is installed: {result.stdout.strip()}")
            return True
        else:
            print("❌ PostgreSQL not found in PATH")
            return False
    except FileNotFoundError:
        print("❌ PostgreSQL not installed or not in PATH")
        return False

def download_postgresql():
    """Provide instructions for downloading PostgreSQL"""
    print("\n" + "="*60)
    print("PostgreSQL Installation Instructions")
    print("="*60)
    print("1. Go to: https://www.postgresql.org/download/windows/")
    print("2. Download the Windows installer")
    print("3. Run the installer as Administrator")
    print("4. During installation:")
    print("   - Set a password for the 'postgres' user (remember this!)")
    print("   - Use default port 5432")
    print("   - Use default locale")
    print("5. After installation, PostgreSQL should start automatically")
    print("\nAlternatively, you can use the EDB installer:")
    print("https://www.enterprisedb.com/downloads/postgres-postgresql-downloads")

def reset_postgres_password():
    """Instructions for resetting PostgreSQL password"""
    print("\n" + "="*60)
    print("Reset PostgreSQL Password Instructions")
    print("="*60)
    print("If you forgot your PostgreSQL password:")
    print()
    print("1. Open Command Prompt as Administrator")
    print("2. Stop PostgreSQL service:")
    print("   net stop postgresql-x64-14")
    print()
    print("3. Find PostgreSQL data directory (usually):")
    print("   C:\\Program Files\\PostgreSQL\\14\\data")
    print()
    print("4. Edit pg_hba.conf file:")
    print("   - Open: C:\\Program Files\\PostgreSQL\\14\\data\\pg_hba.conf")
    print("   - Find line: host all all 127.0.0.1/32 md5")
    print("   - Change 'md5' to 'trust'")
    print("   - Save file")
    print()
    print("5. Start PostgreSQL service:")
    print("   net start postgresql-x64-14")
    print()
    print("6. Connect without password:")
    print("   psql -U postgres")
    print()
    print("7. Change password:")
    print("   ALTER USER postgres PASSWORD 'new_password';")
    print()
    print("8. Restore pg_hba.conf (change 'trust' back to 'md5')")
    print("9. Restart PostgreSQL service")

def check_common_issues():
    """Check and suggest fixes for common PostgreSQL issues"""
    print("\n" + "="*60)
    print("Checking Common PostgreSQL Issues")
    print("="*60)
    
    # Check if PostgreSQL is installed
    if not check_postgresql_installation():
        download_postgresql()
        return False
    
    # Check if service is running
    if not check_postgresql_service():
        print("\nTrying to start PostgreSQL service...")
        if not start_postgresql_service():
            print("\n⚠️  PostgreSQL service failed to start")
            print("Try these solutions:")
            print("1. Run Command Prompt as Administrator")
            print("2. Run: net start postgresql-x64-14")
            print("3. Check Windows Services (services.msc)")
            print("4. Look for PostgreSQL service and start it manually")
            return False
    
    return True

def main():
    print("PostgreSQL Troubleshooting and Setup Helper")
    print("="*50)
    
    while True:
        print("\nChoose an option:")
        print("1. Check PostgreSQL installation and service")
        print("2. Test database connection")
        print("3. Install PostgreSQL (instructions)")
        print("4. Reset PostgreSQL password (instructions)")
        print("5. Exit")
        
        choice = input("\nEnter your choice (1-5): ").strip()
        
        if choice == '1':
            check_common_issues()
            
        elif choice == '2':
            print("\nTesting PostgreSQL connection...")
            host = input("Host [localhost]: ").strip() or 'localhost'
            port = input("Port [5432]: ").strip() or '5432'
            user = input("Username [postgres]: ").strip() or 'postgres'
            
            success, password = test_connection(host, int(port), user)
            if success:
                print(f"\n✅ Connection successful!")
                print("You can now run the database setup script:")
                print("python setup_database.py")
            
        elif choice == '3':
            download_postgresql()
            
        elif choice == '4':
            reset_postgres_password()
            
        elif choice == '5':
            print("Goodbye!")
            break
            
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
