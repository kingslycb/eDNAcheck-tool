##############################################################################
#
# Enhanced OBIS Species Observation Query with Custom Database Support
# Yassine Kasmi, Thünen-Institut für Fischereiökologie 
# Enhanced with PostgreSQL custom database option
#
##############################################################################

from shiny import App, ui, render, reactive
import pandas as pd
import requests
from geopy.distance import geodesic
import folium
from shinywidgets import output_widget, render_widget
import tempfile
import io
from database_config import db_manager
from htmltools import HTML

# Function to query OBIS API
def query_obis(species_name, lon, lat, buffer=1.0, size=500):
    params = {
        "scientificname": species_name,
        "geometry": f"POLYGON(({lon-buffer} {lat-buffer}, {lon+buffer} {lat-buffer}, {lon+buffer} {lat+buffer}, {lon-buffer} {lat+buffer}, {lon-buffer} {lat-buffer}))",
        "size": size,
    }
    response = requests.get("https://api.obis.org/v3/occurrence", params=params)
    return response.json().get("results", []) if response.status_code == 200 else []

# Function to process observations with data source selection
def process_observations(df, data_source='OBIS'):
    input_samples = []
    results = []

    for _, row in df.iterrows():
        species_name = row["species"]
        lon, lat = row["x"], row["y"]

        input_samples.append({"species": species_name, "longitude": lon, "latitude": lat, "date": row.get("date", "Unknown")})

        # Query data based on selected source
        if data_source == 'OBIS':
            records = query_obis(species_name, lon, lat)
        else:
            records = db_manager.query_species_occurrences(species_name, lon, lat)

        distances = []
        for record in records:
            try:
                record_lon = float(record["decimalLongitude"])
                record_lat = float(record["decimalLatitude"])
                distance = geodesic((lat, lon), (record_lat, record_lon)).km
                distances.append((record, distance))
            except (ValueError, KeyError):
                continue

        sorted_records = sorted(distances, key=lambda x: x[1])[:20]

        for rank, (record, distance) in enumerate(sorted_records, 1):
            results.append({
                "input_species": species_name,
                "input_longitude": lon,
                "input_latitude": lat,
                "input_date": row.get("date", "Unknown"),
                "found_species": record.get("scientificName"),
                "found_longitude": record.get("decimalLongitude"),
                "found_latitude": record.get("decimalLatitude"),
                "found_date": record.get("eventDate"),
                "distance_km": round(distance, 2),
                "rank": rank,
                "data_source": data_source
            })

    return pd.DataFrame(results), input_samples

# Function to create an interactive map
def create_map(input_samples, results_df):
    if not input_samples:
        return None

    # Calculate center point
    center_lat = sum(sample["latitude"] for sample in input_samples) / len(input_samples)
    center_lon = sum(sample["longitude"] for sample in input_samples) / len(input_samples)
    
    m = folium.Map(location=[center_lat, center_lon], zoom_start=5)

    # Add input samples (red markers)
    for sample in input_samples:
        folium.Marker(
            location=[sample["latitude"], sample["longitude"]],
            popup=f"Sample: {sample['species']} ({sample.get('date', 'Unknown')})",
            icon=folium.Icon(color="red", icon="info-sign")
        ).add_to(m)

    # Add found records (blue markers)
    for _, row in results_df.iterrows():
        if pd.notna(row["found_latitude"]) and pd.notna(row["found_longitude"]):
            folium.Marker(
                location=[row["found_latitude"], row["found_longitude"]],
                popup=f"{row['data_source']}: {row['found_species']} ({row['distance_km']} km)",
                icon=folium.Icon(color="blue", icon="info-sign")
            ).add_to(m)

    map_path = tempfile.mktemp(suffix=".html")
    m.save(map_path)
    return map_path

# Define UI with database management
app_ui = ui.page_fluid(
    ui.h1("OBIS & Custom Database Species Query System", style="text-align: center; color: #2E8B57; margin-bottom: 30px;"),
    
    # Database Management Section
    ui.panel_conditional(
        "input.data_source === 'Custom Database'",
        ui.card(
            ui.card_header("Database Management"),
            ui.row(
                ui.column(3, ui.input_text("db_host", "Host", value="localhost")),
                ui.column(3, ui.input_numeric("db_port", "Port", value=5432)),
                ui.column(3, ui.input_text("db_name", "Database Name", value="species_db")),
                ui.column(3, ui.input_text("db_user", "Username", value="postgres"))
            ),
            ui.row(
                ui.column(6, ui.input_password("db_password", "Password")),
            ),
            ui.output_text("db_status"),
            ui.hr(),
            ui.row(
                ui.column(6, ui.input_file("db_import_file", "Import Data to Database", accept=[".csv"])),
                ui.column(6, ui.input_action_button("import_data", "Import Data", class_="btn-warning"))
            ),
            ui.output_text("import_status"),
            ui.output_table("db_stats")
        )
    ),
    
    ui.hr(),
    
    # Data Input Section
    ui.card(
        ui.card_header("Data Input & Processing"),
        ui.row(
            ui.column(4, ui.input_file("file", "Upload Query CSV", accept=[".csv"])),
            ui.column(4, ui.input_text_area("data_input", "Or Paste Data", 
                                           placeholder="species,x,y,date\nClupea harengus,-4.25,55.85,2024-03-15")),
            ui.column(4, ui.input_radio_buttons("data_source", "Data Source", 
                                               choices=["OBIS", "Custom Database"], selected="OBIS"))
        ),
        ui.input_action_button("process", "Process Query", class_="btn-success", style="width: 100%; margin-top: 10px;")
    ),
    
    ui.hr(),
    
    # Results Section
    ui.row(
        ui.column(6, 
            ui.card(
                ui.card_header("Query Results"),
                ui.output_table("result_table")
            )
        ),
        ui.column(6, 
            ui.card(
                ui.card_header("Input Summary"),
                ui.output_table("input_table")
            )
        )
    ),
    
    # Map Section
    ui.card(
        ui.card_header("Interactive Map"),
        output_widget("map_output")
    ),
    
    # Download Section
    ui.row(
        ui.column(6, ui.download_button("download_table", "Download Results CSV", class_="btn-primary")),
        ui.column(6, ui.download_button("download_map", "Download Map", class_="btn-secondary"))
    )
)

# Define server logic
def server(input, output, session):
    
    # Remove the old db_status and connect_database logic, and add auto-connect logic
    @reactive.Calc
    def auto_connect_database():
        if input.data_source() == "Custom Database":
            try:
                success = db_manager.connect(
                    host=input.db_host(),
                    port=input.db_port(),
                    database=input.db_name(),
                    user=input.db_user(),
                    password=input.db_password()
                )
                if success:
                    db_manager.create_species_table()
                    return "Connected successfully"
                else:
                    return "Connection failed"
            except Exception as e:
                return f"Connection error: {str(e)}"
        else:
            return "Database not connected"

    @output
    @render.text
    def db_status():
        return auto_connect_database()
    
    # Import data to database
    @reactive.event(input.import_data)
    def import_database():
        # Ensure this function depends on the connection status
        status = auto_connect_database()
        if input.db_import_file() and db_manager.connection:
            try:
                df = pd.read_csv(input.db_import_file()[0]["datapath"])
                inserted = db_manager.insert_species_data(df)
                return f"Imported {inserted} records successfully"
            except Exception as e:
                return f"Import error: {str(e)}"
        return "No file selected or database not connected"
    
    # Import status
    @output
    @render.text
    def import_status():
        if hasattr(import_database, '_value'):
            return import_database()
        return ""
    
    # Database statistics
    @output
    @render.table
    def db_stats():
        if db_manager.connection:
            stats = db_manager.get_database_stats()
            if stats:
                return pd.DataFrame([stats])
        return pd.DataFrame()
    
    # Process query data
    @reactive.event(input.process)
    def process_data():
        try:
            if input.file():
                df = pd.read_csv(input.file()[0]["datapath"])
            else:
                from io import StringIO
                df = pd.read_csv(StringIO(input.data_input()), sep=",")

            if set(["species", "x", "y", "date"]).issubset(df.columns):
                data_source = input.data_source() or 'OBIS'
                
                # Check database connection for custom database
                if data_source == 'Custom Database' and not db_manager.connection:
                    return pd.DataFrame({"Error": ["Please connect to database first"]}), []
                
                result_df, input_samples = process_observations(df, data_source)
                return result_df, input_samples
            else:
                return pd.DataFrame({"Error": ["CSV must have columns: species, x, y, date"]}), []
                
        except Exception as e:
            return pd.DataFrame({"Error": [f"Processing error: {str(e)}"]}), []

    # Display results
    @output
    @render.table
    def result_table():
        result_df, _ = process_data()
        return result_df

    @output
    @render.table
    def input_table():
        _, input_samples = process_data()
        return pd.DataFrame(input_samples)

    # Generate map
    @output
    @render_widget
    def map_output():
        result_df, input_samples = process_data()
        if not input_samples:
            return "No data to display"
        
        map_path = create_map(input_samples, result_df)
        if map_path:
            with open(map_path, "r", encoding="utf-8") as f:
                map_html = f.read()
            return HTML(map_html)
        return "Map generation failed"

    # Download handlers
    @output
    @render.download(filename="species_query_results.csv")
    def download_table():
        result_df, _ = process_data()
        return result_df.to_csv(index=False)

    @output
    @render.download(filename="species_map.html")
    def download_map():
        result_df, input_samples = process_data()
        map_path = create_map(input_samples, result_df)
        if map_path:
            with open(map_path, 'r', encoding='utf-8') as f:
                return f.read()
        return "Map not available"

app = App(app_ui, server)

if __name__ == "__main__":
    app.run()
