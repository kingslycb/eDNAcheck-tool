##############################################################################
#
# Yassine Kasmi,
# Thünen-Institut für Fischereiökologie 
# Bremerhaven
# 2025.03.31
# 
# Shiny app for OBIS
#
# The objective of this script is to compare the observed species from eDNA with
# the data from marinespecies.org database and provide minimal information.
# 
# The script present the 20 most near observation for each input (species)
# The input file should be csv and looks like: species, x,y, date
# the header is important
# to run it from python use
# from shiny import run_app
# run_app("test.py")
#
# OR pip install shiny
# python app.py
# access in http://127.0.0.1:8000/
#
##############################################################################


from shiny import App, ui, render, reactive
import pandas as pd
import requests
from geopy.distance import geodesic
import folium
from shinywidgets import output_widget, render_widget
import tempfile
import io
from database_config import db_manager  # Import database manager

# Function to query OBIS API
def query_obis(species_name, lon, lat, buffer=1.0, size=500):
    params = {
        "scientificname": species_name,
        "geometry": f"POLYGON(({lon-buffer} {lat-buffer}, {lon+buffer} {lat-buffer}, {lon+buffer} {lat+buffer}, {lon-buffer} {lat+buffer}, {lon-buffer} {lat-buffer}))",
        "size": size,
    }
    response = requests.get("https://api.obis.org/v3/occurrence", params=params)
    return response.json().get("results", []) if response.status_code == 200 else []

# Function to process observations
def process_observations(df, data_source='OBIS'):
    input_samples = []
    results = []

    for _, row in df.iterrows():
        species_name = row["species"]
        lon, lat = row["x"], row["y"]

        input_samples.append({"species": species_name, "longitude": lon, "latitude": lat, "date": row.get("date", "Unknown")})

        if data_source == 'OBIS':
            records = query_obis(species_name, lon, lat)
        else:
            records = db_manager.query_species_occurrences(species_name, lon, lat)

        distances = []
        for record in records:
            try:
                obis_lon = float(record["decimalLongitude"])
                obis_lat = float(record["decimalLatitude"])
                distance = geodesic((lat, lon), (obis_lat, obis_lon)).km
                distances.append((record, distance))
            except (ValueError, KeyError):
                continue

        sorted_records = sorted(distances, key=lambda x: x[1])[:20]

        for rank, (record, distance) in enumerate(sorted_records, 1):
            results.append({
                "input_species": species_name,
                "input_longitude": lon,
                "input_latitude": lat,
                "input_date": row.get("date", "Unknown"),
                "obis_species": record.get("scientificName"),
                "obis_longitude": record.get("decimalLongitude"),
                "obis_latitude": record.get("decimalLatitude"),
                "obis_date": record.get("eventDate"),
                "distance_km": round(distance, 2),
                "rank": rank
            })

    return pd.DataFrame(results), input_samples

# Function to create an interactive map
def create_map(input_samples, obis_results):
    if not input_samples:
        return None

    # Calculate the bounds for the map based on input samples and OBIS results
    all_lons = [sample["longitude"] for sample in input_samples] + [record["decimalLongitude"] for record in obis_results]
    all_lats = [sample["latitude"] for sample in input_samples] + [record["decimalLatitude"] for record in obis_results]
    
    min_lon, max_lon = min(all_lons), max(all_lons)
    min_lat, max_lat = min(all_lats), max(all_lats)
    
    # Set the map to show the bounding box that covers all points
    m = folium.Map(location=[(min_lat + max_lat) / 2, (min_lon + max_lon) / 2], 
                   zoom_start=2)  # Zoom level 2 for global view

    # Add input samples
    for sample in input_samples:
        folium.Marker(
            location=[sample["latitude"], sample["longitude"]],
            popup=f"Sample: {sample['species']} ({sample.get('date', 'Unknown')})",
            icon=folium.Icon(color="red", icon="info-sign")
        ).add_to(m)

    # Add OBIS results
    for _, row in obis_results.iterrows():
        folium.Marker(
            location=[row["obis_latitude"], row["obis_longitude"]],
            popup=f"OBIS: {row['obis_species']} ({row['distance_km']} km)",
            icon=folium.Icon(color="blue", icon="info-sign")
        ).add_to(m)

    # Save map to a temporary file
    map_path = tempfile.mktemp(suffix=".html")
    m.save(map_path)
    return map_path

# Define UI
app_ui = ui.page_fluid(
    ui.h2("OBIS Species Observation Query with Custom Database Option", style="text-align: center; color: #4CAF50; font-weight: bold;"),
    ui.row(
        ui.column(4, ui.input_file("file", "Upload CSV", accept=[".csv"], width="100%")),
        ui.column(4, ui.input_text_area("data_input", "Or Paste Data (CSV format)", placeholder="species,x,y,date\nSardina,10.5,50.2,2025-03-30", width="100%")),
        ui.column(4, ui.input_radio_buttons("data_source", "Select Data Source", choices=["OBIS", "Custom Database"], selected="OBIS", width="100%"))
    ),
    ui.input_action_button("process", "Process Data", style="background-color: #4CAF50; color: white; font-size: 16px; width: 100%"),
    ui.row(
        ui.column(6, ui.output_table("result_table")),
        ui.column(6, ui.output_table("input_table"))
    ),
    ui.row(
        ui.column(12, output_widget("map_output"))
    ),
    ui.row(
        ui.column(6, ui.download_button("download_table", "Download Results as CSV")),
        ui.column(6, ui.download_button("download_map", "Download Map"))
    ),
    style="background-color: #f0f0f0; padding: 20px; border-radius: 8px;"
)

# Define server
def server(input, output, session):
    @reactive.event(input.process)
    def process_data():
        if input.file():
            df = pd.read_csv(input.file()[0]["datapath"])
        else:
            from io import StringIO
            df = pd.read_csv(StringIO(input.data_input()), sep=",")

        if set(["species", "x", "y", "date"]).issubset(df.columns):
            data_source = input.data_source() or 'OBIS'
            result_df, input_samples = process_observations(df, data_source)
            return result_df, input_samples
        else:
            return pd.DataFrame(), []

    @output
    @render.table
    def result_table():
        result_df, _ = process_data()
        return result_df

    @output
    @render.table
    def input_table():
        _, input_samples = process_data()
        return pd.DataFrame(input_samples)

    @output
    @render_widget
    def map_output():
        result_df, input_samples = process_data()
        map_path = create_map(input_samples, result_df)
        return map_path if map_path else "No map available"

    @output
    @render.download
    def download_table():
        result_df, _ = process_data()
        csv_data = result_df.to_csv(index=False)
        return io.BytesIO(csv_data.encode('utf-8'))

    @output
    @render.download
    def download_map():
        result_df, input_samples = process_data()
        map_path = create_map(input_samples, result_df)
        return map_path

app = App(app_ui, server)
