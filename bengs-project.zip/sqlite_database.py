##############################################################################
#
# SQLite Database Alternative
# Simple file-based database option that doesn't require PostgreSQL
#
##############################################################################

import sqlite3
import pandas as pd
import os
from typing import List, Dict, Any
import random
from datetime import datetime, timedelta

class SQLiteManager:
    def __init__(self, db_path="species_database.db"):
        self.db_path = db_path
        self.connection = None
    
    def connect(self):
        """Connect to SQLite database"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.row_factory = sqlite3.Row  # Enable dict-like access
            return True
        except Exception as e:
            print(f"SQLite connection error: {e}")
            return False
    
    def disconnect(self):
        """Close SQLite connection"""
        if self.connection:
            self.connection.close()
    
    def create_species_table(self) -> bool:
        """Create the species occurrences table"""
        create_table_query = """
        CREATE TABLE IF NOT EXISTS species_occurrences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scientificName TEXT,
            decimalLongitude REAL,
            decimalLatitude REAL,
            eventDate TEXT,
            dataset_id TEXT,
            datasetName TEXT,
            occurrenceID TEXT UNIQUE,
            recordedBy TEXT,
            basisOfRecord TEXT,
            license TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE INDEX IF NOT EXISTS idx_species_name ON species_occurrences(scientificName);
        CREATE INDEX IF NOT EXISTS idx_coordinates ON species_occurrences(decimalLongitude, decimalLatitude);
        CREATE INDEX IF NOT EXISTS idx_event_date ON species_occurrences(eventDate);
        """
        
        try:
            self.connection.executescript(create_table_query)
            self.connection.commit()
            return True
        except Exception as e:
            print(f"Error creating table: {e}")
            return False
    
    def insert_species_data(self, data_df: pd.DataFrame) -> int:
        """Insert species data from DataFrame"""
        inserted_count = 0
        
        insert_query = """
        INSERT OR IGNORE INTO species_occurrences 
        (scientificName, decimalLongitude, decimalLatitude, eventDate, 
         dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            cursor = self.connection.cursor()
            for _, row in data_df.iterrows():
                cursor.execute(insert_query, (
                    row.get('scientificName', ''),
                    float(row.get('decimalLongitude', 0)) if row.get('decimalLongitude') else None,
                    float(row.get('decimalLatitude', 0)) if row.get('decimalLatitude') else None,
                    row.get('eventDate', None),
                    row.get('dataset_id', ''),
                    row.get('datasetName', ''),
                    row.get('occurrenceID', f"custom_{inserted_count}"),
                    row.get('recordedBy', ''),
                    row.get('basisOfRecord', ''),
                    row.get('license', '')
                ))
                if cursor.rowcount > 0:
                    inserted_count += 1
            
            self.connection.commit()
            return inserted_count
            
        except Exception as e:
            print(f"Error inserting data: {e}")
            return 0
    
    def query_species_occurrences(self, species_name: str, lon: float, lat: float, 
                                buffer: float = 1.0, size: int = 500) -> List[Dict[str, Any]]:
        """Query species occurrences within bounding box"""
        query = """
        SELECT scientificName, decimalLongitude, decimalLatitude, eventDate,
               dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license
        FROM species_occurrences
        WHERE scientificName LIKE ?
        AND decimalLongitude BETWEEN ? AND ?
        AND decimalLatitude BETWEEN ? AND ?
        AND decimalLongitude IS NOT NULL
        AND decimalLatitude IS NOT NULL
        LIMIT ?
        """
        
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, (
                f"%{species_name}%",
                lon - buffer,
                lon + buffer,
                lat - buffer,
                lat + buffer,
                size
            ))
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'scientificName': row['scientificName'],
                    'decimalLongitude': float(row['decimalLongitude']),
                    'decimalLatitude': float(row['decimalLatitude']),
                    'eventDate': row['eventDate'],
                    'dataset_id': row['dataset_id'],
                    'datasetName': row['datasetName'],
                    'occurrenceID': row['occurrenceID'],
                    'recordedBy': row['recordedBy'],
                    'basisOfRecord': row['basisOfRecord'],
                    'license': row['license']
                })
            
            return results
            
        except Exception as e:
            print(f"Error querying species: {e}")
            return []
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        try:
            cursor = self.connection.cursor()
            
            # Total records
            cursor.execute("SELECT COUNT(*) FROM species_occurrences")
            total_records = cursor.fetchone()[0]
            
            # Unique species
            cursor.execute("SELECT COUNT(DISTINCT scientificName) FROM species_occurrences")
            unique_species = cursor.fetchone()[0]
            
            # Date range
            cursor.execute("""
                SELECT MIN(eventDate) as min_date, MAX(eventDate) as max_date 
                FROM species_occurrences 
                WHERE eventDate IS NOT NULL AND eventDate != ''
            """)
            date_range = cursor.fetchone()
            
            return {
                'total_records': total_records,
                'unique_species': unique_species,
                'date_range': {
                    'min_date': date_range[0] if date_range[0] else None,
                    'max_date': date_range[1] if date_range[1] else None
                }
            }
            
        except Exception as e:
            print(f"Error getting stats: {e}")
            return {}

def generate_sample_data(num_records=1000):
    """Generate sample species occurrence data"""
    
    # Common marine species
    species_list = [
        "Clupea harengus",
        "Gadus morhua", 
        "Salmo salar",
        "Engraulis encrasicolus",
        "Scomber scombrus",
        "Sardina pilchardus",
        "Pleuronectes platessa",
        "Solea solea",
        "Merlangius merlangus",
        "Pollachius virens",
        "Abra alba",
        "Acartia clausii",
        "Acartia tonsa",
        "Calanus finmarchicus",
        "Temora longicornis"
    ]
    
    # Geographic bounds (roughly North Atlantic)
    lat_min, lat_max = 45.0, 70.0
    lon_min, lon_max = -30.0, 30.0
    
    # Date range (last 5 years)
    end_date = datetime.now()
    start_date = end_date - timedelta(days=5*365)
    
    data = []
    for i in range(num_records):
        species = random.choice(species_list)
        lat = random.uniform(lat_min, lat_max)
        lon = random.uniform(lon_min, lon_max)
        
        # Random date within range
        random_days = random.randint(0, (end_date - start_date).days)
        event_date = start_date + timedelta(days=random_days)
        
        data.append({
            'scientificName': species,
            'decimalLongitude': round(lon, 6),
            'decimalLatitude': round(lat, 6),
            'eventDate': event_date.strftime('%Y-%m-%d'),
            'dataset_id': f"dataset_{random.randint(1, 10)}",
            'datasetName': f"Marine Survey Dataset {random.randint(1, 10)}",
            'occurrenceID': f"sqlite_occurrence_{i+1:06d}",
            'recordedBy': f"Researcher_{random.randint(1, 20)}",
            'basisOfRecord': random.choice(['HumanObservation', 'MachineObservation', 'PreservedSpecimen']),
            'license': 'CC-BY'
        })
    
    return pd.DataFrame(data)

def setup_sqlite_database(db_path="species_database.db"):
    """Setup SQLite database with sample data"""
    print(f"Setting up SQLite database: {db_path}")
    
    # Initialize database manager
    db_manager = SQLiteManager(db_path)
    
    if not db_manager.connect():
        print("Failed to connect to SQLite database")
        return False
    
    # Create table
    if not db_manager.create_species_table():
        print("Failed to create species table")
        return False
    
    print("Database table created successfully")
    
    # Generate and insert sample data
    print("Generating sample data...")
    sample_data = generate_sample_data(1000)
    
    print("Inserting sample data...")
    inserted_count = db_manager.insert_species_data(sample_data)
    
    print(f"Successfully inserted {inserted_count} sample records")
    
    # Show statistics
    stats = db_manager.get_database_stats()
    print("\nDatabase Statistics:")
    print(f"Total records: {stats.get('total_records', 0)}")
    print(f"Unique species: {stats.get('unique_species', 0)}")
    print(f"Date range: {stats.get('date_range', {}).get('min_date')} to {stats.get('date_range', {}).get('max_date')}")
    
    db_manager.disconnect()
    return True

if __name__ == "__main__":
    print("SQLite Database Setup for Species Occurrences")
    print("=" * 50)
    
    db_path = input("Database file path [species_database.db]: ").strip() or "species_database.db"
    
    success = setup_sqlite_database(db_path)
    
    if success:
        print(f"\n✅ SQLite database setup completed successfully!")
        print(f"Database file: {os.path.abspath(db_path)}")
        print("\nYou can now use this as a custom database option.")
    else:
        print("\n❌ SQLite database setup failed!")
