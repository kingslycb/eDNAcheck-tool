# OBIS & Custom Database Species Query System

An enhanced Shiny application for querying marine species occurrence data from both OBIS (Ocean Biodiversity Information System) and custom PostgreSQL databases.

## Features

- **Dual Data Sources**: Query species from OBIS API or your custom PostgreSQL database
- **Interactive Web Interface**: User-friendly Shiny app with real-time processing
- **Database Management**: Built-in tools to connect, import data, and manage your custom database
- **Interactive Maps**: Visualize input samples and found species on interactive maps
- **Data Export**: Download results as CSV and maps as HTML files
- **Scalable**: Designed to handle large datasets with PostgreSQL backend

## Project Structure

```
Mr Beng Project/
├── Shiny_Enhanced_DB.py      # Main enhanced Shiny application
├── database_config.py        # PostgreSQL database management
├── setup_database.py         # Database setup and sample data generation
├── requirements.txt          # Python dependencies
├── ExampleInput.csv          # Sample input data
├── Shiny_W02.py             # Original Shiny app (for reference)
└── README.md                # This file
```

## Prerequisites

1. **Python 3.8+**
2. **PostgreSQL 12+** (for custom database option)
3. **Virtual Environment** (recommended)

## Installation

### Quick Setup (Recommended)

```bash
# Navigate to project directory
cd "C:\xampp\htdocs\Mr Beng Project"

# Activate virtual environment
venv\Scripts\activate

# Install requirements
pip install -r requirements.txt

# Quick setup with SQLite database
python quick_setup.py
```

### Alternative: PostgreSQL Setup (Advanced)

For production use with large datasets:

1. **Install PostgreSQL**: Download from [postgresql.org](https://www.postgresql.org/download/)
2. **Troubleshoot connection**: Run `python install_postgres.py` for help
3. **Setup database**: Run `python setup_database.py` with your credentials

## Usage

### Running the Application

```bash
# Make sure you're in the project directory
cd "C:\xampp\htdocs\Mr Beng Project"

# Activate virtual environment
venv\Scripts\activate

# Run the enhanced Shiny app
python Shiny_Enhanced_DB.py
```

The application will be available at: `http://127.0.0.1:8000/`

### Using OBIS Data Source

1. Select "OBIS" as data source
2. Upload CSV file or paste data in the format:
   ```
   species,x,y,date
   Clupea harengus,-4.25,55.85,2024-03-15
   Gadus morhua,-5.30,53.20,2024-01-10
   ```
3. Click "Process Query"

### Using Custom Database

1. Select "Custom Database" as data source
2. Enter database connection details:
   - Host: localhost (or your PostgreSQL server)
   - Port: 5432 (default PostgreSQL port)
   - Database Name: species_db
   - Username: postgres (or your PostgreSQL user)
   - Password: [your PostgreSQL password]
3. Click "Connect to Database"
4. Import data if needed using the CSV upload feature
5. Process queries as normal

## Input Data Format

CSV files should contain the following columns:

- **species**: Scientific name of the species
- **x**: Longitude (decimal degrees)
- **y**: Latitude (decimal degrees)  
- **date**: Date in YYYY-MM-DD format

Example:
```csv
species,x,y,date
Clupea harengus,-4.25,55.85,2024-03-15
Salmo salar,-2.10,57.65,2024-02-20
Gadus morhua,-5.30,53.20,2024-01-10
```

## Database Schema

The custom database uses the following schema:

```sql
CREATE TABLE species_occurrences (
    id SERIAL PRIMARY KEY,
    scientificName VARCHAR(255),
    decimalLongitude DECIMAL(10, 7),
    decimalLatitude DECIMAL(10, 7),
    eventDate DATE,
    dataset_id VARCHAR(100),
    datasetName VARCHAR(255),
    occurrenceID VARCHAR(255) UNIQUE,
    recordedBy VARCHAR(255),
    basisOfRecord VARCHAR(100),
    license VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Output

The application provides:

1. **Results Table**: Shows the 20 nearest species occurrences for each input species
2. **Interactive Map**: Displays input locations (red markers) and found species (blue markers)
3. **CSV Export**: Download results for further analysis
4. **HTML Map Export**: Save interactive maps

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check PostgreSQL is running
   - Verify connection credentials
   - Ensure database exists

2. **Import Errors**
   - Check CSV format matches expected schema
   - Verify database connection is active

3. **No Results Found**
   - Check species names are spelled correctly
   - Increase search buffer size (modify in code)
   - Verify data exists in selected source

### Performance Tips

- Use indexed columns for faster queries
- Limit query size for large datasets
- Consider geographic clustering for better performance

## Development

### Adding New Features

1. **New Data Sources**: Extend `process_observations()` function
2. **Additional Filters**: Modify database queries in `database_config.py`
3. **UI Enhancements**: Update the Shiny UI components

### Contributing

1. Fork the repository
2. Create feature branch
3. Test thoroughly
4. Submit pull request

## License

This project is developed for research purposes at Thünen-Institut für Fischereiökologie.

## Contact

Yassine Kasmi  
Thünen-Institut für Fischereiökologie  
Bremerhaven, Germany

---

*Last updated: 2025-07-03*
