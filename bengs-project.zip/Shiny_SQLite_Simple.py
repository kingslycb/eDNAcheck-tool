##############################################################################
#
# Simplified OBIS & SQLite Species Query System
# Automatically uses the SQLite database created by quick_setup.py
#
##############################################################################

from shiny import App, ui, render, reactive
import pandas as pd
import requests
from geopy.distance import geodesic
import folium
from shinywidgets import output_widget, render_widget
import tempfile
import io
import sqlite3
import os

# Function to query OBIS API
def query_obis(species_name, lon, lat, buffer=1.0, size=500):
    params = {
        "scientificname": species_name,
        "geometry": f"POLYGON(({lon-buffer} {lat-buffer}, {lon+buffer} {lat-buffer}, {lon+buffer} {lat+buffer}, {lon-buffer} {lat+buffer}, {lon-buffer} {lat-buffer}))",
        "size": size,
    }
    response = requests.get("https://api.obis.org/v3/occurrence", params=params)
    return response.json().get("results", []) if response.status_code == 200 else []

# Function to query SQLite database
def query_sqlite_database(species_name, lon, lat, buffer=1.0, size=500):
    db_path = "species_database.db"
    
    if not os.path.exists(db_path):
        print(f"SQLite database not found at {db_path}")
        return []
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        query = """
        SELECT scientificName, decimalLongitude, decimalLatitude, eventDate,
               dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license
        FROM species_occurrences
        WHERE scientificName LIKE ?
        AND decimalLongitude BETWEEN ? AND ?
        AND decimalLatitude BETWEEN ? AND ?
        AND decimalLongitude IS NOT NULL
        AND decimalLatitude IS NOT NULL
        LIMIT ?
        """
        
        cursor.execute(query, (
            f"%{species_name}%",
            lon - buffer,
            lon + buffer,
            lat - buffer,
            lat + buffer,
            size
        ))
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'scientificName': row['scientificName'],
                'decimalLongitude': float(row['decimalLongitude']),
                'decimalLatitude': float(row['decimalLatitude']),
                'eventDate': row['eventDate'],
                'dataset_id': row['dataset_id'],
                'datasetName': row['datasetName'],
                'occurrenceID': row['occurrenceID'],
                'recordedBy': row['recordedBy'],
                'basisOfRecord': row['basisOfRecord'],
                'license': row['license']
            })
        
        conn.close()
        return results
        
    except Exception as e:
        print(f"Error querying SQLite database: {e}")
        return []

# Function to get database statistics
def get_sqlite_stats():
    db_path = "species_database.db"
    
    if not os.path.exists(db_path):
        return {"status": "Database not found"}
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Total records
        cursor.execute("SELECT COUNT(*) FROM species_occurrences")
        total_records = cursor.fetchone()[0]
        
        # Unique species
        cursor.execute("SELECT COUNT(DISTINCT scientificName) FROM species_occurrences")
        unique_species = cursor.fetchone()[0]
        
        # Date range
        cursor.execute("""
            SELECT MIN(eventDate) as min_date, MAX(eventDate) as max_date 
            FROM species_occurrences 
            WHERE eventDate IS NOT NULL AND eventDate != ''
        """)
        date_range = cursor.fetchone()
        
        conn.close()
        
        return {
            'status': 'Connected',
            'total_records': total_records,
            'unique_species': unique_species,
            'date_range': {
                'min_date': date_range[0] if date_range[0] else None,
                'max_date': date_range[1] if date_range[1] else None
            }
        }
        
    except Exception as e:
        return {"status": f"Error: {str(e)}"}

# Function to process observations with data source selection
def process_observations(df, data_source='OBIS'):
    input_samples = []
    results = []

    for _, row in df.iterrows():
        species_name = row["species"]
        lon, lat = row["x"], row["y"]

        input_samples.append({"species": species_name, "longitude": lon, "latitude": lat, "date": row.get("date", "Unknown")})

        # Query data based on selected source
        if data_source == 'OBIS':
            records = query_obis(species_name, lon, lat)
        else:
            records = query_sqlite_database(species_name, lon, lat)

        distances = []
        for record in records:
            try:
                record_lon = float(record["decimalLongitude"])
                record_lat = float(record["decimalLatitude"])
                distance = geodesic((lat, lon), (record_lat, record_lon)).km
                distances.append((record, distance))
            except (ValueError, KeyError):
                continue

        sorted_records = sorted(distances, key=lambda x: x[1])[:20]

        for rank, (record, distance) in enumerate(sorted_records, 1):
            results.append({
                "input_species": species_name,
                "input_longitude": lon,
                "input_latitude": lat,
                "input_date": row.get("date", "Unknown"),
                "found_species": record.get("scientificName"),
                "found_longitude": record.get("decimalLongitude"),
                "found_latitude": record.get("decimalLatitude"),
                "found_date": record.get("eventDate"),
                "distance_km": round(distance, 2),
                "rank": rank,
                "data_source": data_source
            })

    return pd.DataFrame(results), input_samples

# Function to create an interactive map
def create_map(input_samples, results_df):
    if not input_samples:
        return None

    # Calculate center point
    center_lat = sum(sample["latitude"] for sample in input_samples) / len(input_samples)
    center_lon = sum(sample["longitude"] for sample in input_samples) / len(input_samples)
    
    m = folium.Map(location=[center_lat, center_lon], zoom_start=5)

    # Add input samples (red markers)
    for sample in input_samples:
        folium.Marker(
            location=[sample["latitude"], sample["longitude"]],
            popup=f"Sample: {sample['species']} ({sample.get('date', 'Unknown')})",
            icon=folium.Icon(color="red", icon="info-sign")
        ).add_to(m)

    # Add found records (blue markers)
    for _, row in results_df.iterrows():
        if pd.notna(row["found_latitude"]) and pd.notna(row["found_longitude"]):
            folium.Marker(
                location=[row["found_latitude"], row["found_longitude"]],
                popup=f"{row['data_source']}: {row['found_species']} ({row['distance_km']} km)",
                icon=folium.Icon(color="blue", icon="info-sign")
            ).add_to(m)

    map_path = tempfile.mktemp(suffix=".html")
    m.save(map_path)
    return map_path

# Define UI
app_ui = ui.page_fluid(
    ui.h1("OBIS & Custom Database Species Query System", style="text-align: center; color: #2E8B57; margin-bottom: 30px;"),
    
    # Database Status Section
    ui.card(
        ui.card_header("Database Status"),
        ui.output_table("db_status_table"),
        style="margin-bottom: 20px;"
    ),
    
    # Data Input Section
    ui.card(
        ui.card_header("Data Input & Processing"),
        ui.row(
            ui.column(4, ui.input_file("file", "Upload Query CSV", accept=[".csv"])),
            ui.column(4, ui.input_text_area("data_input", "Or Paste Data", 
                                           placeholder="species,x,y,date\nClupea harengus,-4.25,55.85,2024-03-15")),
            ui.column(4, ui.input_radio_buttons("data_source", "Data Source", 
                                               choices=["OBIS", "Custom SQLite Database"], selected="OBIS"))
        ),
        ui.input_action_button("process", "Process Query", class_="btn-success", style="width: 100%; margin-top: 10px;")
    ),
    
    ui.hr(),
    
    # Results Section
    ui.row(
        ui.column(6, 
            ui.card(
                ui.card_header("Query Results"),
                ui.output_table("result_table")
            )
        ),
        ui.column(6, 
            ui.card(
                ui.card_header("Input Summary"),
                ui.output_table("input_table")
            )
        )
    ),
    
    # Map Section
    ui.card(
        ui.card_header("Interactive Map"),
        output_widget("map_output")
    ),
    
    # Download Section
    ui.row(
        ui.column(6, ui.download_button("download_table", "Download Results CSV", class_="btn-primary")),
        ui.column(6, ui.download_button("download_map", "Download Map", class_="btn-secondary"))
    )
)

# Define server logic
def server(input, output, session):
    
    # Database status
    @output
    @render.table
    def db_status_table():
        stats = get_sqlite_stats()
        return pd.DataFrame([stats])
    
    # Process query data
    @reactive.event(input.process)
    def process_data():
        try:
            if input.file():
                df = pd.read_csv(input.file()[0]["datapath"])
            else:
                from io import StringIO
                df = pd.read_csv(StringIO(input.data_input()), sep=",")

            if set(["species", "x", "y", "date"]).issubset(df.columns):
                data_source = input.data_source() or 'OBIS'
                
                # Check if SQLite database exists for custom database
                if data_source == 'Custom SQLite Database':
                    if not os.path.exists("species_database.db"):
                        return pd.DataFrame({"Error": ["SQLite database not found. Run quick_setup.py first."]}), []
                
                result_df, input_samples = process_observations(df, data_source)
                return result_df, input_samples
            else:
                return pd.DataFrame({"Error": ["CSV must have columns: species, x, y, date"]}), []
                
        except Exception as e:
            return pd.DataFrame({"Error": [f"Processing error: {str(e)}"]}), []

    # Display results
    @output
    @render.table
    def result_table():
        result_df, _ = process_data()
        return result_df

    @output
    @render.table
    def input_table():
        _, input_samples = process_data()
        return pd.DataFrame(input_samples)

    # Generate map
    @output
    @render_widget
    def map_output():
        result_df, input_samples = process_data()
        if not input_samples:
            return None
        
        map_path = create_map(input_samples, result_df)
        if map_path and os.path.exists(map_path):
            # Return the map HTML content for embedding
            with open(map_path, 'r', encoding='utf-8') as f:
                map_html = f.read()
            # Clean up temporary file
            os.unlink(map_path)
            return map_html
        return None

    # Download handlers
    @output
    @render.download(filename="species_query_results.csv")
    def download_table():
        result_df, _ = process_data()
        return io.BytesIO(result_df.to_csv(index=False).encode('utf-8'))

    @output
    @render.download(filename="species_map.html")
    def download_map():
        result_df, input_samples = process_data()
        map_path = create_map(input_samples, result_df)
        if map_path:
            with open(map_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return io.BytesIO(content.encode('utf-8'))
        return io.BytesIO(b"Map not available")

app = App(app_ui, server)

if __name__ == "__main__":
    app.run(port=8001)
