##############################################################################
#
# Database Setup Script for Species Occurrences
# Sets up PostgreSQL database and creates sample data
#
##############################################################################

import pandas as pd
import psycopg2
from psycopg2.extras import RealDictCursor
import random
from datetime import datetime, timedelta

def create_database_if_not_exists(host, port, user, password, db_name):
    """Create database if it doesn't exist"""
    try:
        # Connect to PostgreSQL server (not to a specific database)
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database='postgres'  # Connect to default postgres database
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute(f"SELECT 1 FROM pg_database WHERE datname = '{db_name}'")
        if not cursor.fetchone():
            cursor.execute(f"CREATE DATABASE {db_name}")
            print(f"Database '{db_name}' created successfully")
        else:
            print(f"Database '{db_name}' already exists")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"Error creating database: {e}")
        return False

def generate_sample_data(num_records=1000):
    """Generate sample species occurrence data"""
    
    # Common marine species
    species_list = [
        "Clupea harengus",
        "Gadus morhua", 
        "Salmo salar",
        "Engraulis encrasicolus",
        "Scomber scombrus",
        "Sardina pilchardus",
        "Pleuronectes platessa",
        "Solea solea",
        "Merlangius merlangus",
        "Pollachius virens",
        "Abra alba",
        "Acartia clausii",
        "Acartia tonsa",
        "Calanus finmarchicus",
        "Temora longicornis"
    ]
    
    # Geographic bounds (roughly North Atlantic)
    lat_min, lat_max = 45.0, 70.0
    lon_min, lon_max = -30.0, 30.0
    
    # Date range (last 5 years)
    end_date = datetime.now()
    start_date = end_date - timedelta(days=5*365)
    
    data = []
    for i in range(num_records):
        species = random.choice(species_list)
        lat = random.uniform(lat_min, lat_max)
        lon = random.uniform(lon_min, lon_max)
        
        # Random date within range
        random_days = random.randint(0, (end_date - start_date).days)
        event_date = start_date + timedelta(days=random_days)
        
        data.append({
            'scientificName': species,
            'decimalLongitude': round(lon, 6),
            'decimalLatitude': round(lat, 6),
            'eventDate': event_date.strftime('%Y-%m-%d'),
            'dataset_id': f"dataset_{random.randint(1, 10)}",
            'datasetName': f"Marine Survey Dataset {random.randint(1, 10)}",
            'occurrenceID': f"occurrence_{i+1:06d}",
            'recordedBy': f"Researcher_{random.randint(1, 20)}",
            'basisOfRecord': random.choice(['HumanObservation', 'MachineObservation', 'PreservedSpecimen']),
            'license': 'CC-BY'
        })
    
    return pd.DataFrame(data)

def setup_complete_database(host='localhost', port=5432, user='postgres', password='your_password', db_name='species_db'):
    """Complete database setup with sample data"""
    
    print("Setting up PostgreSQL database for species occurrences...")
    
    # Step 1: Create database
    if not create_database_if_not_exists(host, port, user, password, db_name):
        return False
    
    # Step 2: Connect to the new database and create tables
    try:
        from database_config import DatabaseManager
        
        db_manager = DatabaseManager()
        success = db_manager.connect(host, port, db_name, user, password)
        
        if not success:
            print("Failed to connect to database")
            return False
        
        # Create tables
        if not db_manager.create_species_table():
            print("Failed to create species table")
            return False
        
        print("Database table created successfully")
        
        # Step 3: Generate and insert sample data
        print("Generating sample data...")
        sample_data = generate_sample_data(1000)
        
        print("Inserting sample data...")
        inserted_count = db_manager.insert_species_data(sample_data)
        
        print(f"Successfully inserted {inserted_count} sample records")
        
        # Step 4: Show statistics
        stats = db_manager.get_database_stats()
        print("\nDatabase Statistics:")
        print(f"Total records: {stats.get('total_records', 0)}")
        print(f"Unique species: {stats.get('unique_species', 0)}")
        print(f"Date range: {stats.get('date_range', {}).get('min_date')} to {stats.get('date_range', {}).get('max_date')}")
        
        db_manager.disconnect()
        return True
        
    except Exception as e:
        print(f"Error during database setup: {e}")
        return False

if __name__ == "__main__":
    # Interactive setup for PostgreSQL connection
    print("PostgreSQL Database Setup for Species Occurrences")
    print("=" * 50)
    print("Please enter your PostgreSQL connection details:")
    print()
    
    # Get connection details from user
    host = input("Host [localhost]: ").strip() or 'localhost'
    port = input("Port [5432]: ").strip() or '5432'
    user = input("Username [postgres]: ").strip() or 'postgres'
    
    import getpass
    password = getpass.getpass("Password: ")
    
    db_name = input("Database name [species_db]: ").strip() or 'species_db'
    
    DB_CONFIG = {
        'host': host,
        'port': int(port),
        'user': user,
        'password': password,
        'db_name': db_name
    }
    
    print(f"Database configuration:")
    print(f"Host: {DB_CONFIG['host']}")
    print(f"Port: {DB_CONFIG['port']}")
    print(f"Database: {DB_CONFIG['db_name']}")
    print(f"User: {DB_CONFIG['user']}")
    print()
    
    # Setup database
    success = setup_complete_database(**DB_CONFIG)
    
    if success:
        print("\n✅ Database setup completed successfully!")
        print("\nYou can now use the Shiny app with the custom database option.")
        print("Connection details to use in the app:")
        print(f"Host: {DB_CONFIG['host']}")
        print(f"Port: {DB_CONFIG['port']}")
        print(f"Database: {DB_CONFIG['db_name']}")
        print(f"Username: {DB_CONFIG['user']}")
        print("Password: [the password you set]")
    else:
        print("\n❌ Database setup failed!")
        print("Please check your PostgreSQL installation and connection details.")
