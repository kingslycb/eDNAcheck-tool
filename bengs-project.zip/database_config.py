##############################################################################
#
# Database Configuration Module
# Handles both PostgreSQL and SQLite connections for custom database operations
#
##############################################################################

import pandas as pd
import os
from typing import List, Dict, Any, Optional

# Try to import PostgreSQL and SQLite modules
try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
    POSTGRESQL_AVAILABLE = True
except ImportError:
    POSTGRESQL_AVAILABLE = False
    print("PostgreSQL not available. Only SQLite will be supported.")

try:
    import sqlite3
    SQLITE_AVAILABLE = True
except ImportError:
    SQLITE_AVAILABLE = False
    print("SQLite not available.")

class DatabaseManager:
    def __init__(self, db_type='sqlite', db_path='species_database.db'):
        self.connection = None
        self.cursor = None
        self.db_type = db_type.lower()
        self.db_path = db_path
    
    def connect(self, host: str = None, port: int = None, database: str = None, user: str = None, password: str = None) -> bool:
        """Establish connection to database (PostgreSQL or SQLite)"""
        try:
            if self.db_type == 'postgresql':
                if not POSTGRESQL_AVAILABLE:
                    print("PostgreSQL is not available. Install psycopg2-binary.")
                    return False
                
                self.connection = psycopg2.connect(
                    host=host,
                    port=port,
                    database=database,
                    user=user,
                    password=password
                )
                self.cursor = self.connection.cursor(cursor_factory=RealDictCursor)
                return True
            
            elif self.db_type == 'sqlite':
                if not SQLITE_AVAILABLE:
                    print("SQLite is not available.")
                    return False
                
                self.connection = sqlite3.connect(self.db_path)
                self.connection.row_factory = sqlite3.Row
                self.cursor = self.connection.cursor()
                return True
            
            else:
                print(f"Unsupported database type: {self.db_type}")
                return False
                
        except Exception as e:
            print(f"Database connection error: {e}")
            return False
    
    def disconnect(self):
        """Close database connection"""
        if self.cursor:
            self.cursor.close()
        if self.connection:
            self.connection.close()
    
    def create_species_table(self) -> bool:
        """Create the species occurrences table if it doesn't exist"""
        if self.db_type == 'postgresql':
            create_table_query = """
            CREATE TABLE IF NOT EXISTS species_occurrences (
                id SERIAL PRIMARY KEY,
                scientificName VARCHAR(255),
                decimalLongitude DECIMAL(10, 7),
                decimalLatitude DECIMAL(10, 7),
                eventDate DATE,
                dataset_id VARCHAR(100),
                datasetName VARCHAR(255),
                occurrenceID VARCHAR(255) UNIQUE,
                recordedBy VARCHAR(255),
                basisOfRecord VARCHAR(100),
                license VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE INDEX IF NOT EXISTS idx_species_name ON species_occurrences(scientificName);
            CREATE INDEX IF NOT EXISTS idx_coordinates ON species_occurrences(decimalLongitude, decimalLatitude);
            CREATE INDEX IF NOT EXISTS idx_event_date ON species_occurrences(eventDate);
            """
        else:  # SQLite
            create_table_query = """
            CREATE TABLE IF NOT EXISTS species_occurrences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scientificName TEXT,
                decimalLongitude REAL,
                decimalLatitude REAL,
                eventDate TEXT,
                dataset_id TEXT,
                datasetName TEXT,
                occurrenceID TEXT UNIQUE,
                recordedBy TEXT,
                basisOfRecord TEXT,
                license TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE INDEX IF NOT EXISTS idx_species_name ON species_occurrences(scientificName);
            CREATE INDEX IF NOT EXISTS idx_coordinates ON species_occurrences(decimalLongitude, decimalLatitude);
            CREATE INDEX IF NOT EXISTS idx_event_date ON species_occurrences(eventDate);
            """
        
        try:
            if self.db_type == 'postgresql':
                self.cursor.execute(create_table_query)
                self.connection.commit()
            else:  # SQLite
                self.connection.executescript(create_table_query)
                self.connection.commit()
            return True
        except Exception as e:
            print(f"Error creating table: {e}")
            if self.db_type == 'postgresql':
                self.connection.rollback()
            return False
    
    def insert_species_data(self, data_df: pd.DataFrame) -> int:
        """Insert species data from DataFrame into database"""
        inserted_count = 0
        
        if self.db_type == 'postgresql':
            insert_query = """
            INSERT INTO species_occurrences 
            (scientificName, decimalLongitude, decimalLatitude, eventDate, 
             dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (occurrenceID) DO NOTHING
            """
        else:  # SQLite
            insert_query = """
            INSERT OR IGNORE INTO species_occurrences 
            (scientificName, decimalLongitude, decimalLatitude, eventDate, 
             dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
        
        try:
            for _, row in data_df.iterrows():
                params = (
                    row.get('scientificName', ''),
                    float(row.get('decimalLongitude', 0)) if row.get('decimalLongitude') else None,
                    float(row.get('decimalLatitude', 0)) if row.get('decimalLatitude') else None,
                    row.get('eventDate', None),
                    row.get('dataset_id', ''),
                    row.get('datasetName', ''),
                    row.get('occurrenceID', f"custom_{inserted_count}"),
                    row.get('recordedBy', ''),
                    row.get('basisOfRecord', ''),
                    row.get('license', '')
                )
                
                self.cursor.execute(insert_query, params)
                
                if self.db_type == 'sqlite' and self.cursor.rowcount > 0:
                    inserted_count += 1
                elif self.db_type == 'postgresql':
                    inserted_count += 1
            
            self.connection.commit()
            return inserted_count
            
        except Exception as e:
            print(f"Error inserting data: {e}")
            if self.db_type == 'postgresql':
                self.connection.rollback()
            return 0
    
    def query_species_occurrences(self, species_name: str, lon: float, lat: float, 
                                buffer: float = 1.0, size: int = 500) -> List[Dict[str, Any]]:
        """Query species occurrences within bounding box"""
        if self.db_type == 'postgresql':
            query = """
            SELECT scientificName, decimalLongitude, decimalLatitude, eventDate,
                   dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license
            FROM species_occurrences
            WHERE scientificName ILIKE %s
            AND decimalLongitude BETWEEN %s AND %s
            AND decimalLatitude BETWEEN %s AND %s
            AND decimalLongitude IS NOT NULL
            AND decimalLatitude IS NOT NULL
            LIMIT %s
            """
            params = (
                f"%{species_name}%",
                lon - buffer,
                lon + buffer,
                lat - buffer,
                lat + buffer,
                size
            )
        else:  # SQLite
            query = """
            SELECT scientificName, decimalLongitude, decimalLatitude, eventDate,
                   dataset_id, datasetName, occurrenceID, recordedBy, basisOfRecord, license
            FROM species_occurrences
            WHERE scientificName LIKE ?
            AND decimalLongitude BETWEEN ? AND ?
            AND decimalLatitude BETWEEN ? AND ?
            AND decimalLongitude IS NOT NULL
            AND decimalLatitude IS NOT NULL
            LIMIT ?
            """
            params = (
                f"%{species_name}%",
                lon - buffer,
                lon + buffer,
                lat - buffer,
                lat + buffer,
                size
            )
        
        try:
            self.cursor.execute(query, params)
            
            results = []
            for row in self.cursor.fetchall():
                if self.db_type == 'postgresql':
                    results.append({
                        'scientificName': row['scientificname'],
                        'decimalLongitude': float(row['decimallongitude']),
                        'decimalLatitude': float(row['decimallatitude']),
                        'eventDate': str(row['eventdate']) if row['eventdate'] else None,
                        'dataset_id': row['dataset_id'],
                        'datasetName': row['datasetname'],
                        'occurrenceID': row['occurrenceid'],
                        'recordedBy': row['recordedby'],
                        'basisOfRecord': row['basisofrecord'],
                        'license': row['license']
                    })
                else:  # SQLite
                    results.append({
                        'scientificName': row['scientificName'],
                        'decimalLongitude': float(row['decimalLongitude']),
                        'decimalLatitude': float(row['decimalLatitude']),
                        'eventDate': row['eventDate'],
                        'dataset_id': row['dataset_id'],
                        'datasetName': row['datasetName'],
                        'occurrenceID': row['occurrenceID'],
                        'recordedBy': row['recordedBy'],
                        'basisOfRecord': row['basisOfRecord'],
                        'license': row['license']
                    })
            
            return results
            
        except Exception as e:
            print(f"Error querying species: {e}")
            return []
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        try:
            # Total records
            self.cursor.execute("SELECT COUNT(*) FROM species_occurrences")
            total_records = self.cursor.fetchone()[0]
            
            # Unique species
            self.cursor.execute("SELECT COUNT(DISTINCT scientificName) FROM species_occurrences")
            unique_species = self.cursor.fetchone()[0]
            
            # Date range
            self.cursor.execute("""
                SELECT MIN(eventDate) as min_date, MAX(eventDate) as max_date 
                FROM species_occurrences 
                WHERE eventDate IS NOT NULL
            """)
            date_range = self.cursor.fetchone()
            
            return {
                'total_records': total_records,
                'unique_species': unique_species,
                'date_range': {
                    'min_date': str(date_range[0]) if date_range[0] else None,
                    'max_date': str(date_range[1]) if date_range[1] else None
                }
            }
            
        except Exception as e:
            print(f"Error getting stats: {e}")
            return {}

# Global database manager instance (SQLite by default for easier setup)
db_manager = DatabaseManager(db_type='sqlite', db_path='species_database.db')
