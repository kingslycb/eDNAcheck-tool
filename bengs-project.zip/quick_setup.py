##############################################################################
#
# Quick Setup Script - Creates SQLite database for immediate use
#
##############################################################################

import os
import sys

def setup_sqlite_database():
    """Quick setup using SQLite - no PostgreSQL needed"""
    print("🚀 Quick Setup: Creating SQLite Database")
    print("=" * 50)
    
    try:
        from sqlite_database import setup_sqlite_database
        
        # Create SQLite database with sample data
        db_path = "species_database.db"
        success = setup_sqlite_database(db_path)
        
        if success:
            print(f"\n✅ SQLite database created successfully!")
            print(f"📍 Location: {os.path.abspath(db_path)}")
            print(f"📊 Database size: {os.path.getsize(db_path) / 1024:.1f} KB")
            
            print("\n🎯 Next Steps:")
            print("1. Run the enhanced Shiny app:")
            print("   python Shiny_Enhanced_DB.py")
            print("2. In the app, select 'Custom Database' as data source")
            print("3. The SQLite database will be used automatically")
            print("4. Upload your species CSV or use the sample data")
            
            return True
            
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Make sure all required packages are installed:")
        print("pip install -r requirements.txt")
        return False
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        return False

def main():
    print("Species Database Quick Setup")
    print("=" * 30)
    print()
    print("This script will create a SQLite database with sample marine species data.")
    print("SQLite requires no additional software installation!")
    print()
    
    choice = input("Continue with setup? (y/n): ").lower().strip()
    
    if choice in ['y', 'yes']:
        success = setup_sqlite_database()
        
        if success:
            print("\n🎉 Setup complete! You can now run the application.")
            run_app = input("\nWould you like to run the app now? (y/n): ").lower().strip()
            
            if run_app in ['y', 'yes']:
                print("Starting the application...")
                try:
                    import subprocess
                    subprocess.run([sys.executable, "Shiny_Enhanced_DB.py"])
                except Exception as e:
                    print(f"Could not start app automatically: {e}")
                    print("Please run manually: python Shiny_Enhanced_DB.py")
        else:
            print("\n💡 Troubleshooting:")
            print("- Make sure you're in the project directory")
            print("- Install requirements: pip install -r requirements.txt")
            print("- Check Python version (3.8+ required)")
    else:
        print("Setup cancelled.")

if __name__ == "__main__":
    main()
